"""Analytics Agent — computes real KPIs, chart specs and statistical findings
directly from the ingested DataFrame. No values are hard-coded.
"""
from __future__ import annotations
from core.serialize import to_native
import numpy as np
import pandas as pd

PALETTE = ["#4F7CFF", "#38BDF8", "#8B5CF6", "#10B981", "#F59E0B",
           "#EC4899", "#EF4444", "#14B8A6"]


def _roles(meta: dict) -> dict:
    return meta.get("roles", {})


def _first(meta: dict, role: str):
    cols = _roles(meta).get(role, [])
    return cols[0] if cols else None


def _fmt_money(v: float) -> str:
    a = abs(v)
    if a >= 1e9: return f"${v/1e9:.1f}B"
    if a >= 1e6: return f"${v/1e6:.1f}M"
    if a >= 1e3: return f"${v/1e3:.0f}K"
    return f"${v:,.0f}"


def _fmt_num(v: float) -> str:
    a = abs(v)
    if a >= 1e6: return f"{v/1e6:.1f}M"
    if a >= 1e3: return f"{v/1e3:.1f}K"
    return f"{v:,.0f}"


def _pct(cur: float, prev: float) -> float:
    if prev == 0:
        return 0.0
    return round((cur - prev) / abs(prev) * 100, 1)


def compute_kpis(df: pd.DataFrame, meta: dict) -> list[dict]:
    rev_col = _first(meta, "revenue")
    cost_col = _first(meta, "cost")
    qty_col = _first(meta, "quantity")
    date_col = _first(meta, "date")
    cards: list[dict] = []

    # order by date for trend/sparkline
    d = df.copy()
    if date_col:
        d = d.sort_values(date_col)

    def sparkline(series: pd.Series, buckets: int = 12) -> list[float]:
        s = series.dropna().astype(float)
        if len(s) == 0:
            return [0] * buckets
        if len(s) <= buckets:
            return [round(float(x), 2) for x in s]
        idx = np.array_split(np.arange(len(s)), buckets)
        return [round(float(s.iloc[i].sum()), 2) for i in idx]

    if rev_col:
        total = float(d[rev_col].sum())
        # period-over-period growth on the date axis (fallback: halves)
        if date_col:
            by = d.set_index(date_col)[rev_col].resample("ME").sum()
            trend = _pct(by.iloc[-1], by.iloc[-2]) if len(by) >= 2 else 0.0
            spark = sparkline(by)
        else:
            half = len(d) // 2
            trend = _pct(d[rev_col].iloc[half:].sum(), d[rev_col].iloc[:half].sum())
            spark = sparkline(d[rev_col])
        cards.append(dict(label="Revenue", value=_fmt_money(total),
                          trend=f"{'+' if trend>=0 else ''}{trend}%", up=trend >= 0,
                          color="#4F7CFF", icon="💰", sparkline=spark,
                          insight="Trending up" if trend >= 0 else "Declining"))

        cards.append(dict(label="Avg Order", value=_fmt_money(total / max(len(d), 1)),
                          trend=f"{len(d)} orders", up=True, color="#38BDF8", icon="🛒",
                          sparkline=spark, insight="Per record"))

    if rev_col and cost_col:
        profit = float(d[rev_col].sum() - d[cost_col].sum())
        cost_total = float(d[cost_col].sum())
        roi = (profit / cost_total * 100) if cost_total else 0.0
        margin = (profit / float(d[rev_col].sum()) * 100) if d[rev_col].sum() else 0.0
        cards.append(dict(label="Profit", value=_fmt_money(profit),
                          trend=f"{margin:.1f}% margin", up=profit >= 0, color="#10B981",
                          icon="📈", sparkline=sparkline(d[rev_col] - d[cost_col]),
                          insight="Strong" if margin > 20 else "Thin margin"))
        cards.append(dict(label="ROI", value=f"{roi:.0f}%",
                          trend="cost-adjusted", up=roi >= 0, color="#8B5CF6", icon="🎯",
                          sparkline=sparkline(d[rev_col]), insight="Exceptional" if roi > 100 else "Healthy"))

    if qty_col:
        cards.append(dict(label="Units", value=_fmt_num(float(d[qty_col].sum())),
                          trend="total volume", up=True, color="#F59E0B", icon="📦",
                          sparkline=sparkline(d[qty_col]), insight="Volume"))

    cards.append(dict(label="Records", value=_fmt_num(len(df)),
                      trend=f"{df.shape[1]} columns", up=True, color="#14B8A6", icon="🗂️",
                      sparkline=sparkline(pd.Series(np.ones(len(df)))), insight="Dataset size"))
    return cards[:8]


def _chart(kind: str, title: str, labels, datasets, note="") -> dict:
    return {"kind": kind, "title": title, "note": note,
            "data": {"labels": list(labels), "datasets": datasets}}


def build_charts(df: pd.DataFrame, meta: dict) -> list[dict]:
    """Auto-select chart types based on detected column roles."""
    rev = _first(meta, "revenue")
    cost = _first(meta, "cost")
    date = _first(meta, "date")
    region = _first(meta, "region")
    product = _first(meta, "product")
    category = _first(meta, "category")
    charts: list[dict] = []

    # 1. Revenue (+cost) over time -> line/area
    if rev and date:
        by = df.dropna(subset=[date]).set_index(date)[rev].resample("ME").sum()
        ds = [{"label": rev, "data": [round(float(v), 2) for v in by.values],
               "borderColor": "#4F7CFF", "backgroundColor": "rgba(79,124,255,0.08)",
               "fill": True, "tension": 0.4, "borderWidth": 2, "pointRadius": 0}]
        if cost:
            byc = df.dropna(subset=[date]).set_index(date)[cost].resample("ME").sum().reindex(by.index).fillna(0)
            ds.append({"label": cost, "data": [round(float(v), 2) for v in byc.values],
                       "borderColor": "#8B5CF6", "backgroundColor": "rgba(139,92,246,0.05)",
                       "fill": True, "tension": 0.4, "borderWidth": 2, "pointRadius": 0})
        charts.append(_chart("line", f"{rev} over time",
                             [i.strftime("%b %Y") for i in by.index], ds))

    # 2. Revenue by region -> bar
    if rev and region:
        g = df.groupby(region)[rev].sum().sort_values(ascending=False).head(8)
        charts.append(_chart("bar", f"{rev} by {region}", g.index.astype(str),
                             [{"label": rev, "data": [round(float(v), 2) for v in g.values],
                               "backgroundColor": [PALETTE[i % len(PALETTE)] for i in range(len(g))],
                               "borderRadius": 6}]))

    # 3. Category share -> pie
    share_col = category or product or region
    if rev and share_col:
        g = df.groupby(share_col)[rev].sum().sort_values(ascending=False).head(6)
        charts.append(_chart("pie", f"{rev} share by {share_col}", g.index.astype(str),
                             [{"data": [round(float(v), 2) for v in g.values],
                               "backgroundColor": [PALETTE[i % len(PALETTE)] for i in range(len(g))],
                               "borderColor": "#0B1020", "borderWidth": 3}]))

    # 4. Top products -> horizontal bar
    if rev and product:
        g = df.groupby(product)[rev].sum().sort_values(ascending=False).head(7)
        charts.append(_chart("bar", f"Top {product}s by {rev}", g.index.astype(str),
                             [{"label": rev, "data": [round(float(v), 2) for v in g.values],
                               "backgroundColor": "#38BDF8", "borderRadius": 6}], note="horizontal"))

    # Fallback: distribution of the first numeric column
    if not charts:
        num = df.select_dtypes(include="number")
        if num.shape[1]:
            col = num.columns[0]
            counts, edges = np.histogram(num[col].dropna(), bins=8)
            labels = [f"{edges[i]:.0f}-{edges[i+1]:.0f}" for i in range(len(counts))]
            charts.append(_chart("bar", f"Distribution of {col}", labels,
                                 [{"label": col, "data": [int(c) for c in counts],
                                   "backgroundColor": "#4F7CFF", "borderRadius": 6}]))
    return charts


def findings(df: pd.DataFrame, meta: dict) -> dict:
    rev = _first(meta, "revenue")
    region = _first(meta, "region")
    product = _first(meta, "product")
    customer = _first(meta, "customer")
    out: dict = {}

    if rev and product:
        g = df.groupby(product)[rev].sum().sort_values(ascending=False)
        out["top_products"] = [{"name": str(k), "value": _fmt_money(float(v))}
                               for k, v in g.head(5).items()]
    if rev and customer:
        g = df.groupby(customer)[rev].sum().sort_values(ascending=False)
        out["top_customers"] = [{"name": str(k), "value": _fmt_money(float(v))}
                                for k, v in g.head(5).items()]
    if rev and region:
        g = df.groupby(region)[rev].sum().sort_values(ascending=False)
        out["regions"] = [{"name": str(k), "value": _fmt_money(float(v))} for k, v in g.items()]

    # outliers via IQR on revenue
    if rev:
        s = df[rev].dropna()
        q1, q3 = s.quantile(0.25), s.quantile(0.75)
        iqr = q3 - q1
        hi = s[(s > q3 + 1.5 * iqr)]
        out["outliers"] = {"count": int(len(hi)), "threshold": _fmt_money(float(q3 + 1.5 * iqr))}

    # correlation matrix of numeric columns
    num = df.select_dtypes(include="number")
    if num.shape[1] >= 2:
        corr = num.corr(numeric_only=True).round(2)
        out["correlation"] = {"columns": list(corr.columns),
                              "matrix": corr.values.tolist()}

    return out


def analyze(df: pd.DataFrame, meta: dict) -> dict:
    return to_native({
        "kpis": compute_kpis(df, meta),
        "charts": build_charts(df, meta),
        "findings": findings(df, meta),
    })
