"""Forecast Agent.

Builds a time series from the dataset (revenue aggregated by date) and forecasts
future periods with a confidence interval. Uses Facebook Prophet when installed;
otherwise falls back to a robust trend + seasonality decomposition — so it always
returns a real forecast, never dummy numbers.
"""
from __future__ import annotations
from core.serialize import to_native
import numpy as np
import pandas as pd

try:
    from prophet import Prophet  # optional heavy dependency
    _HAS_PROPHET = True
except Exception:
    _HAS_PROPHET = False


def _series(df: pd.DataFrame, meta: dict) -> pd.Series | None:
    roles = meta.get("roles", {})
    date_col = (roles.get("date") or [None])[0]
    val_col = (roles.get("revenue") or roles.get("quantity") or [None])[0]
    if not date_col or not val_col:
        num = df.select_dtypes(include="number")
        if not date_col or num.shape[1] == 0:
            return None
        val_col = num.columns[0]
    s = (df[[date_col, val_col]].dropna()
           .set_index(date_col)[val_col]
           .resample("ME").sum())
    return s if len(s) >= 3 else None


def _statistical_forecast(s: pd.Series, periods: int) -> dict:
    y = s.values.astype(float)
    x = np.arange(len(y))
    # linear trend
    coef = np.polyfit(x, y, 1)
    trend = np.poly1d(coef)
    resid = y - trend(x)
    # monthly seasonal component
    months = s.index.month
    seasonal = pd.Series(resid, index=months).groupby(level=0).mean()
    sigma = float(np.std(resid)) or float(np.std(y)) or 1.0

    future_idx = pd.date_range(s.index[-1], periods=periods + 1, freq="ME")[1:]
    fx = np.arange(len(y), len(y) + periods)
    base = trend(fx)
    seas = np.array([seasonal.get(m, 0.0) for m in future_idx.month])
    yhat = base + seas
    ci = 1.96 * sigma * np.sqrt(1 + np.arange(1, periods + 1) / len(y))
    return {"index": future_idx, "yhat": yhat, "lo": yhat - ci, "hi": yhat + ci}


def _prophet_forecast(s: pd.Series, periods: int) -> dict:
    dfp = pd.DataFrame({"ds": s.index, "y": s.values})
    m = Prophet(interval_width=0.95, weekly_seasonality=False, daily_seasonality=False)
    m.fit(dfp)
    future = m.make_future_dataframe(periods=periods, freq="ME")
    fc = m.predict(future).tail(periods)
    return {"index": pd.to_datetime(fc["ds"].values),
            "yhat": fc["yhat"].values, "lo": fc["yhat_lower"].values,
            "hi": fc["yhat_upper"].values}


def forecast(df: pd.DataFrame, meta: dict, periods: int = 6) -> dict:
    s = _series(df, meta)
    if s is None:
        return {"available": False,
                "reason": "Need a date column and a numeric measure to forecast."}
    engine = "prophet" if _HAS_PROPHET else "statistical"
    fc = (_prophet_forecast(s, periods) if _HAS_PROPHET
          else _statistical_forecast(s, periods))

    hist_labels = [i.strftime("%b %Y") for i in s.index]
    fut_labels = [i.strftime("%b %Y") for i in fc["index"]]
    total_next = float(np.sum(fc["yhat"]))
    last_actual = float(s.iloc[-1])
    change = round((float(fc["yhat"][0]) - last_actual) / abs(last_actual) * 100, 1) if last_actual else 0.0

    return to_native({
        "available": True,
        "engine": engine,
        "periods": periods,
        "history": {"labels": hist_labels, "values": [round(float(v), 2) for v in s.values]},
        "forecast": {
            "labels": fut_labels,
            "yhat": [round(float(v), 2) for v in fc["yhat"]],
            "lower": [round(float(v), 2) for v in fc["lo"]],
            "upper": [round(float(v), 2) for v in fc["hi"]],
        },
        "summary": {
            "next_period": round(float(fc["yhat"][0]), 2),
            "total_forecast": round(total_next, 2),
            "expected_change_pct": change,
            "direction": "up" if change >= 0 else "down",
        },
    })
