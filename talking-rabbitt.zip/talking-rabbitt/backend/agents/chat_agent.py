"""Chat Agent — answers natural-language questions about the active dataset.

If an OpenAI or Gemini key is configured it uses the LLM with a compact,
factual dataset context (schema + KPIs + key aggregates). With no key it falls
back to a deterministic rule-based analyst that routes keywords to real pandas
computations — so the chat is always dataset-aware and never returns canned text.
"""
from __future__ import annotations
import json
import urllib.request
import pandas as pd

from core import config
from agents import analytics_agent as aa
from agents import forecast_agent as fa


# ----------------------------------------------------------------------
# context builder — a compact factual brief the LLM can reason over
# ----------------------------------------------------------------------
def build_context(df: pd.DataFrame, meta: dict) -> str:
    an = aa.analyze(df, meta)
    lines = [f"Dataset: {meta.get('filename')} ({meta['rows']} rows, {meta['cols']} cols)."]
    lines.append("Columns (name:role): " +
                 ", ".join(f"{c['name']}:{c['role']}" for c in meta["schema"]))
    lines.append("KPIs: " + "; ".join(f"{k['label']}={k['value']} ({k['trend']})"
                                       for k in an["kpis"]))
    f = an["findings"]
    if f.get("top_products"):
        lines.append("Top products: " + ", ".join(f"{p['name']} {p['value']}"
                                                   for p in f["top_products"]))
    if f.get("regions"):
        lines.append("Regions: " + ", ".join(f"{r['name']} {r['value']}"
                                              for r in f["regions"]))
    if f.get("outliers"):
        lines.append(f"Revenue outliers above {f['outliers']['threshold']}: {f['outliers']['count']}.")
    return "\n".join(lines)


# ----------------------------------------------------------------------
# LLM providers
# ----------------------------------------------------------------------
def _openai(messages: list[dict]) -> str:
    body = json.dumps({"model": config.OPENAI_MODEL, "messages": messages,
                       "temperature": 0.3}).encode()
    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions", data=body,
        headers={"Authorization": f"Bearer {config.OPENAI_API_KEY}",
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.loads(r.read())["choices"][0]["message"]["content"]


def _gemini(prompt: str) -> str:
    url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
           f"{config.GEMINI_MODEL}:generateContent?key={config.GEMINI_API_KEY}")
    body = json.dumps({"contents": [{"parts": [{"text": prompt}]}]}).encode()
    req = urllib.request.Request(url, data=body,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=45) as r:
        data = json.loads(r.read())
        return data["candidates"][0]["content"]["parts"][0]["text"]


# ----------------------------------------------------------------------
# rule-based fallback analyst (no API key required)
# ----------------------------------------------------------------------
def _rule_based(question: str, df: pd.DataFrame, meta: dict) -> dict:
    q = question.lower()
    an = aa.analyze(df, meta)
    f = an["findings"]
    roles = meta.get("roles", {})

    def role(r):
        return (roles.get(r) or [None])[0]

    # forecast intent
    if any(w in q for w in ["forecast", "predict", "next month", "future", "projection"]):
        fc = fa.forecast(df, meta)
        if fc.get("available"):
            s = fc["summary"]
            text = (f"**Forecast ({fc['engine']} engine)**\n\n"
                    f"Next period is projected at **{s['next_period']:,}**, "
                    f"an expected **{s['expected_change_pct']}%** move "
                    f"({s['direction']}). Total over the next {fc['periods']} periods: "
                    f"**{s['total_forecast']:,}**.")
            chart = {"kind": "line", "title": "Forecast",
                     "data": {"labels": fc["history"]["labels"] + fc["forecast"]["labels"],
                              "datasets": [
                                  {"label": "Actual", "data": fc["history"]["values"] + [None]*len(fc["forecast"]["labels"]),
                                   "borderColor": "#4F7CFF", "tension": 0.4},
                                  {"label": "Forecast", "data": [None]*len(fc["history"]["labels"]) + fc["forecast"]["yhat"],
                                   "borderColor": "#8B5CF6", "borderDash": [6, 4], "tension": 0.4}]}}
            return {"text": text, "chart": chart}

    # top / best performers
    if any(w in q for w in ["top", "best", "highest", "leading"]):
        if "customer" in q and f.get("top_customers"):
            rows = [[c["name"], c["value"]] for c in f["top_customers"]]
            return {"text": "Here are your top customers by revenue:",
                    "table": {"headers": ["Customer", "Revenue"], "rows": rows}}
        if f.get("top_products"):
            rows = [[p["name"], p["value"]] for p in f["top_products"]]
            return {"text": "Here are the top performers by revenue:",
                    "table": {"headers": ["Product", "Revenue"], "rows": rows}}

    # region comparison
    if any(w in q for w in ["region", "regional", "geography", "area", "location"]) and f.get("regions"):
        rows = [[r["name"], r["value"]] for r in f["regions"]]
        chart = next((c for c in an["charts"] if "region" in c["title"].lower()), None)
        return {"text": "Regional revenue comparison:",
                "table": {"headers": ["Region", "Revenue"], "rows": rows},
                "chart": chart}

    # why decrease / drop
    if any(w in q for w in ["why", "decrease", "drop", "decline", "fall", "down"]):
        rev, date = role("revenue"), role("date")
        if rev and date:
            by = df.dropna(subset=[date]).set_index(date)[rev].resample("ME").sum()
            if len(by) >= 2:
                delta = aa._pct(by.iloc[-1], by.iloc[-2])
                worst = by.idxmin().strftime("%b %Y")
                return {"text": (f"The most recent period moved **{delta}%** vs the prior period. "
                                 f"The weakest month was **{worst}**. Key drivers are usually "
                                 f"seasonality, channel mix and pricing — drill into those columns "
                                 f"to isolate the cause.")}
    # what should we do
    if any(w in q for w in ["should", "recommend", "advice", "improve", "action"]):
        from agents import recommendation_agent as ra
        recs = ra.recommend(df, meta)[:3]
        body = "\n\n".join(f"**{r['title']}** — {r['desc']} _Action: {r['action']}_"
                           for r in recs)
        return {"text": "Based on the data, here's what I'd prioritise:\n\n" + body}

    # default: KPI summary
    kpi = "; ".join(f"{k['label']} {k['value']} ({k['trend']})" for k in an["kpis"])
    return {"text": (f"Here's a snapshot of **{meta.get('filename')}**:\n\n{kpi}\n\n"
                     f"Ask me about top products, regional performance, forecasts, or "
                     f"what actions to take.")}


# ----------------------------------------------------------------------
# public entry point
# ----------------------------------------------------------------------
def answer(question: str, df: pd.DataFrame, meta: dict, history: list[dict]) -> dict:
    provider = config.active_llm()
    context = build_context(df, meta)

    if provider == "none":
        return _rule_based(question, df, meta)

    system = ("You are a senior business intelligence analyst. Answer ONLY from the "
              "dataset facts below. Be concise, use markdown, cite concrete numbers. "
              "If asked for a forecast or a breakdown you don't have, say so.\n\n"
              f"DATASET FACTS:\n{context}")
    try:
        if provider == "openai":
            msgs = [{"role": "system", "content": system}]
            for m in history[-6:]:
                msgs.append({"role": "user" if m["role"] == "user" else "assistant",
                             "content": m.get("text", "")})
            msgs.append({"role": "user", "content": question})
            return {"text": _openai(msgs), "provider": "openai"}
        else:
            prompt = f"{system}\n\nQuestion: {question}\nAnswer:"
            return {"text": _gemini(prompt), "provider": "gemini"}
    except Exception as e:
        # graceful degradation to the rule-based analyst
        res = _rule_based(question, df, meta)
        res["note"] = f"LLM unavailable ({type(e).__name__}); used built-in analyst."
        return res
