"""Report Agent — builds executive PDF, Excel and CSV exports from real data."""
from __future__ import annotations
import io
import pandas as pd

from agents import analytics_agent as aa
from agents import recommendation_agent as ra


def _summary_text(df, meta):
    an = aa.analyze(df, meta)
    kpis = an["kpis"]
    top = ", ".join(k["label"] + " " + k["value"] for k in kpis[:4])
    return (f"This report summarises {meta['rows']:,} records across {meta['cols']} "
            f"columns from {meta.get('filename')}. Headline metrics: {top}.")


def build_csv(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode()


def build_excel(df: pd.DataFrame, meta: dict) -> bytes:
    an = aa.analyze(df, meta)
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter") as xl:
        pd.DataFrame(an["kpis"])[["label", "value", "trend", "insight"]].to_excel(
            xl, sheet_name="KPIs", index=False)
        pd.DataFrame(ra.recommend(df, meta))[["title", "priority", "impact", "confidence", "action"]].to_excel(
            xl, sheet_name="Recommendations", index=False)
        df.to_excel(xl, sheet_name="Data", index=False)
    return buf.getvalue()


def build_pdf(df: pd.DataFrame, meta: dict) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import cm
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                    TableStyle)
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    an = aa.analyze(df, meta)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title="Talking Rabbitt Report")
    styles = getSampleStyleSheet()
    h = ParagraphStyle("h", parent=styles["Title"], textColor=colors.HexColor("#4F7CFF"))
    story = [Paragraph("Talking Rabbitt — Executive Report", h),
             Paragraph(meta.get("filename", ""), styles["Normal"]), Spacer(1, 0.4 * cm),
             Paragraph("Executive Summary", styles["Heading2"]),
             Paragraph(_summary_text(df, meta), styles["Normal"]), Spacer(1, 0.4 * cm),
             Paragraph("Key Performance Indicators", styles["Heading2"])]

    kpi_rows = [["Metric", "Value", "Trend", "Insight"]] + \
               [[k["label"], k["value"], k["trend"], k["insight"]] for k in an["kpis"]]
    t = Table(kpi_rows, hAlign="LEFT")
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#111827")),
                           ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                           ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")),
                           ("FONTSIZE", (0, 0), (-1, -1), 9),
                           ("ROWBACKGROUNDS", (0, 1), (-1, -1),
                            [colors.white, colors.HexColor("#f1f5f9")])]))
    story += [t, Spacer(1, 0.4 * cm), Paragraph("AI Recommendations", styles["Heading2"])]
    for r in ra.recommend(df, meta)[:5]:
        story.append(Paragraph(
            f"<b>{r['title']}</b> ({r['priority']}, impact {r['impact']}, "
            f"confidence {r['confidence']}%)<br/>{r['desc']} <i>Action: {r['action']}</i>",
            styles["Normal"]))
        story.append(Spacer(1, 0.2 * cm))
    doc.build(story)
    return buf.getvalue()
