"""Recommendation Agent — derives actionable recommendations from computed
statistics. Each recommendation carries confidence, impact, reasoning and a
suggested action, all grounded in the data.
"""
from __future__ import annotations
from core.serialize import to_native
import numpy as np
import pandas as pd


def _first(meta, role):
    return (meta.get("roles", {}).get(role) or [None])[0]


def recommend(df: pd.DataFrame, meta: dict) -> list[dict]:
    rev = _first(meta, "revenue")
    cost = _first(meta, "cost")
    region = _first(meta, "region")
    product = _first(meta, "product")
    qty = _first(meta, "quantity")
    customer = _first(meta, "customer")
    date = _first(meta, "date")
    recs: list[dict] = []

    # 1. Underperforming region -> reallocate marketing
    if rev and region:
        g = df.groupby(region)[rev].sum().sort_values()
        if len(g) >= 2:
            worst, best = g.index[0], g.index[-1]
            gap = round((g.iloc[-1] - g.iloc[0]) / g.iloc[-1] * 100, 1)
            recs.append(dict(
                title=f"Boost investment in {worst}", icon="📢", priority="high",
                impact=min(90, int(gap)), confidence=88,
                desc=f"{worst} generated {gap}% less revenue than {best}. Reallocating "
                     f"marketing toward {worst} could close the gap.",
                action=f"Shift budget from saturated {best} to {worst}.",
                reasoning=f"Revenue by {region}: min {worst} vs max {best}."))

    # 2. Revenue concentration risk (single product/customer dominance)
    for col, kind in [(product, "product"), (customer, "customer")]:
        if rev and col:
            g = df.groupby(col)[rev].sum().sort_values(ascending=False)
            share = float(g.iloc[0] / g.sum() * 100) if g.sum() else 0
            if share > 30:
                recs.append(dict(
                    title=f"Reduce {kind} concentration risk", icon="⚠️",
                    priority="high" if share > 50 else "medium",
                    impact=int(min(85, share)), confidence=90,
                    desc=f"{g.index[0]} accounts for {share:.0f}% of revenue. "
                         f"Over-reliance on one {kind} is a risk.",
                    action=f"Diversify beyond {g.index[0]}.",
                    reasoning=f"Top {kind} share = {share:.0f}% of total {rev}."))
                break

    # 3. Inventory / demand pressure
    if qty and product:
        g = df.groupby(product)[qty].sum().sort_values(ascending=False)
        top = g.index[0]
        recs.append(dict(
            title=f"Prioritise stock for {top}", icon="📦", priority="medium",
            impact=70, confidence=84,
            desc=f"{top} has the highest volume ({int(g.iloc[0]):,} units). "
                 f"Ensure supply keeps pace with demand.",
            action=f"Review reorder point for {top}.",
            reasoning=f"Highest-volume item by {qty}."))

    # 4. Margin / pricing
    if rev and cost:
        margin = float((df[rev].sum() - df[cost].sum()) / df[rev].sum() * 100) if df[rev].sum() else 0
        if margin < 20:
            recs.append(dict(
                title="Improve pricing / margin", icon="💎", priority="high",
                impact=80, confidence=82,
                desc=f"Overall margin is {margin:.1f}%, below a healthy 20% threshold.",
                action="Test a modest price increase on low-elasticity lines.",
                reasoning=f"(Revenue-Cost)/Revenue = {margin:.1f}%."))

    # 5. Trend-based
    if rev and date:
        by = df.dropna(subset=[date]).set_index(date)[rev].resample("ME").sum()
        if len(by) >= 3:
            recent = by.iloc[-3:].mean()
            prev = by.iloc[:-3].mean() if len(by) > 3 else by.iloc[0]
            change = round((recent - prev) / abs(prev) * 100, 1) if prev else 0
            if change < 0:
                recs.append(dict(
                    title="Reverse the downward trend", icon="📉", priority="high",
                    impact=85, confidence=86,
                    desc=f"Recent revenue is {abs(change)}% below the earlier baseline.",
                    action="Launch a retention + reactivation campaign.",
                    reasoning=f"Recent vs baseline monthly {rev}: {change}%."))
            else:
                recs.append(dict(
                    title="Double down on what's working", icon="🚀", priority="low",
                    impact=60, confidence=80,
                    desc=f"Revenue is trending up {change}%. Reinforce successful channels.",
                    action="Scale the highest-ROI activities.",
                    reasoning=f"Recent vs baseline monthly {rev}: +{change}%."))

    if not recs:
        recs.append(dict(
            title="Enrich the dataset", icon="🧭", priority="medium", impact=50,
            confidence=70,
            desc="Add date, revenue, cost or region columns to unlock deeper recommendations.",
            action="Upload a richer transactional dataset.",
            reasoning="No revenue/region/date signals detected."))
    return to_native(recs)
