"""Data Ingestion Agent.

Reads CSV/Excel, infers schema, cleans data, and — critically — detects the
*semantic role* of each column (date / revenue / cost / quantity / region /
product / customer / category) so the rest of the platform can compute real
KPIs without any hard-coded assumptions about column names.
"""
from __future__ import annotations
import io
import re
import numpy as np
import pandas as pd

# keyword hints for semantic role detection
_HINTS = {
    "date":     ["date", "time", "day", "month", "year", "period", "timestamp", "created", "order date"],
    "revenue":  ["revenue", "sales", "amount", "total", "price", "gross", "income", "turnover", "value"],
    "cost":     ["cost", "expense", "cogs", "spend", "budget", "cost of"],
    "profit":   ["profit", "margin", "net", "earnings"],
    "quantity": ["qty", "quantity", "units", "count", "volume", "stock", "inventory"],
    "region":   ["region", "state", "country", "city", "territory", "zone", "location", "area", "market"],
    "product":  ["product", "item", "sku", "model", "goods"],
    "customer": ["customer", "client", "account", "buyer", "user", "company", "name"],
    "category": ["category", "segment", "type", "class", "group", "department", "channel", "campaign"],
}


def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    seen: dict[str, int] = {}
    new = []
    for c in df.columns:
        name = str(c).strip()
        if not name or name.lower().startswith("unnamed"):
            name = f"column_{len(new)}"
        if name in seen:
            seen[name] += 1
            name = f"{name}_{seen[name]}"
        else:
            seen[name] = 0
        new.append(name)
    df.columns = new
    return df


def _coerce_types(df: pd.DataFrame) -> pd.DataFrame:
    for col in df.columns:
        s = df[col]
        # object (pandas<3) or str/string dtype (pandas>=3) => candidate for coercion
        if not pd.api.types.is_numeric_dtype(s) and not pd.api.types.is_datetime64_any_dtype(s):
            # strip currency / thousands separators then try numeric
            cleaned = (s.astype(str)
                        .str.replace(r"[,$€£%\s]", "", regex=True)
                        .replace({"": np.nan, "nan": np.nan, "None": np.nan}))
            num = pd.to_numeric(cleaned, errors="coerce")
            if num.notna().mean() > 0.8:          # mostly numeric -> convert
                df[col] = num
                continue
            dt = pd.to_datetime(s, errors="coerce", format="mixed")
            if dt.notna().mean() > 0.7:           # mostly parseable dates
                df[col] = dt
    return df


def _handle_missing(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    missing = {c: int(df[c].isna().sum()) for c in df.columns}
    for col in df.columns:
        if df[col].isna().any():
            if pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(df[col].median())
            elif pd.api.types.is_datetime64_any_dtype(df[col]):
                df[col] = df[col].ffill().bfill()
            else:
                mode = df[col].mode()
                df[col] = df[col].fillna(mode.iloc[0] if len(mode) else "Unknown")
    return df, missing


def _semantic_role(col: str, series: pd.Series) -> str:
    name = col.lower()
    for role, hints in _HINTS.items():
        if any(h in name for h in hints):
            # guard: a "date" hint on a numeric non-datetime col shouldn't win
            if role == "date" and not pd.api.types.is_datetime64_any_dtype(series):
                if not pd.api.types.is_numeric_dtype(series):
                    return "date"
                continue
            return role
    if pd.api.types.is_datetime64_any_dtype(series):
        return "date"
    return "numeric" if pd.api.types.is_numeric_dtype(series) else "categorical"


def _logical_type(series: pd.Series) -> str:
    if pd.api.types.is_datetime64_any_dtype(series):
        return "Date"
    if pd.api.types.is_numeric_dtype(series):
        return "Number"
    nunique = series.nunique(dropna=True)
    if nunique <= max(20, int(0.05 * len(series))):
        return "Category"
    return "String"


def read_table(raw: bytes, filename: str) -> pd.DataFrame:
    name = filename.lower()
    if name.endswith((".xlsx", ".xls")):
        return pd.read_excel(io.BytesIO(raw))
    # CSV / TSV — sniff the separator
    sep = "\t" if name.endswith(".tsv") else None
    return pd.read_csv(io.BytesIO(raw), sep=sep, engine="python")


def ingest(raw: bytes, filename: str) -> tuple[pd.DataFrame, dict]:
    """Return the cleaned DataFrame and a rich metadata dict."""
    df = read_table(raw, filename)
    raw_rows = int(df.shape[0])
    df = _normalize_columns(df)
    df = _coerce_types(df)
    before = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    duplicates_removed = before - len(df)
    df, missing = _handle_missing(df)

    schema = []
    roles: dict[str, list[str]] = {}
    for col in df.columns:
        role = _semantic_role(col, df[col])
        ltype = _logical_type(df[col])
        roles.setdefault(role, []).append(col)
        col_meta = {
            "name": col,
            "type": ltype,
            "role": role,
            "missing": missing.get(col, 0),
            "unique": int(df[col].nunique(dropna=True)),
        }
        if pd.api.types.is_numeric_dtype(df[col]):
            col_meta.update({
                "min": float(np.nanmin(df[col])) if len(df) else 0.0,
                "max": float(np.nanmax(df[col])) if len(df) else 0.0,
                "mean": float(np.nanmean(df[col])) if len(df) else 0.0,
            })
        schema.append(col_meta)

    sample = df.head(5).astype(object).where(pd.notna(df.head(5)), None).values.tolist()

    metadata = {
        "filename": filename,
        "raw_rows": raw_rows,
        "rows": int(df.shape[0]),
        "cols": int(df.shape[1]),
        "duplicates_removed": int(duplicates_removed),
        "total_missing": int(sum(missing.values())),
        "schema": schema,
        "roles": roles,
        "columns": list(df.columns),
        "types": [c["type"] for c in schema],
        "sample_rows": sample,
    }
    return df, metadata
