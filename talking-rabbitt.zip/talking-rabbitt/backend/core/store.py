"""In-memory + on-disk registry for datasets, history, chats and reports.

A DataFrame is kept in memory for fast analytics and mirrored to a parquet
file on disk so the process can recover state after a restart.
"""
from __future__ import annotations
import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Optional
import pandas as pd

from .config import STORAGE_DIR

_DATASETS: dict[str, "Dataset"] = {}
_HISTORY: list[dict] = []
_CHATS: dict[str, list[dict]] = {}          # dataset_id -> messages
_REPORTS: list[dict] = []
_META_FILE = STORAGE_DIR / "registry.json"


@dataclass
class Dataset:
    id: str
    name: str
    rows: int
    cols: int
    columns: list[str]
    metadata: dict = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    _df: Optional[pd.DataFrame] = None

    @property
    def df(self) -> pd.DataFrame:
        if self._df is None:                     # lazy reload from parquet
            self._df = pd.read_pickle(STORAGE_DIR / f"{self.id}.pkl")
        return self._df

    def public(self) -> dict:
        d = {k: v for k, v in asdict(self).items() if k != "_df"}
        return d


def add_dataset(name: str, df: pd.DataFrame, metadata: dict) -> Dataset:
    ds_id = uuid.uuid4().hex[:12]
    df.to_pickle(STORAGE_DIR / f"{ds_id}.pkl")
    ds = Dataset(id=ds_id, name=name, rows=int(df.shape[0]), cols=int(df.shape[1]),
                 columns=list(df.columns), metadata=metadata, _df=df)
    _DATASETS[ds_id] = ds
    log_history("upload", f"Uploaded {name}", {"dataset_id": ds_id, "rows": ds.rows})
    _persist()
    return ds


def get_dataset(ds_id: str) -> Optional[Dataset]:
    return _DATASETS.get(ds_id)


def list_datasets() -> list[dict]:
    return [d.public() for d in sorted(_DATASETS.values(), key=lambda x: -x.created_at)]


def latest_dataset() -> Optional[Dataset]:
    if not _DATASETS:
        return None
    return max(_DATASETS.values(), key=lambda x: x.created_at)


# ---- chat -------------------------------------------------------------
def get_chat(ds_id: str) -> list[dict]:
    return _CHATS.setdefault(ds_id, [])


def append_chat(ds_id: str, message: dict) -> None:
    _CHATS.setdefault(ds_id, []).append(message)


# ---- history / reports ------------------------------------------------
def log_history(kind: str, title: str, meta: dict | None = None) -> dict:
    entry = {"id": uuid.uuid4().hex[:8], "kind": kind, "title": title,
             "meta": meta or {}, "time": time.time()}
    _HISTORY.insert(0, entry)
    return entry


def list_history() -> list[dict]:
    return _HISTORY


def log_report(entry: dict) -> None:
    _REPORTS.insert(0, entry)
    log_history("report", f"Generated report: {entry.get('name','report')}", entry)


def list_reports() -> list[dict]:
    return _REPORTS


# ---- persistence ------------------------------------------------------
def _persist() -> None:
    meta = {"datasets": [d.public() for d in _DATASETS.values()]}
    _META_FILE.write_text(json.dumps(meta, default=str))


def restore() -> None:
    """Rebuild the registry from disk on startup (best-effort)."""
    if not _META_FILE.exists():
        return
    try:
        meta = json.loads(_META_FILE.read_text())
        for d in meta.get("datasets", []):
            if (STORAGE_DIR / f"{d['id']}.parquet").exists():
                _DATASETS[d["id"]] = Dataset(
                    id=d["id"], name=d["name"], rows=d["rows"], cols=d["cols"],
                    columns=d["columns"], metadata=d.get("metadata", {}),
                    created_at=d.get("created_at", time.time()))
    except Exception:
        pass
