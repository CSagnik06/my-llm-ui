"""Talking Rabbitt — AI Business Intelligence backend (FastAPI)."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from core import config, store
from api import (upload, analytics, chat, forecast, recommendations,
                 reports, history, database)

app = FastAPI(title="Talking Rabbitt API", version="1.0.0",
              description="AI-powered Business Intelligence backend.")

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _startup():
    store.restore()


@app.get("/api/health")
def health():
    ds = store.latest_dataset()
    return {"status": "ok", "llm": config.active_llm(),
            "active_dataset": ds.id if ds else None,
            "datasets": len(store.list_datasets())}


for r in (upload, analytics, chat, forecast, recommendations, reports, history, database):
    app.include_router(r.router, prefix="/api")
