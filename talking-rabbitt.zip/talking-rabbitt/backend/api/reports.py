import time
from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from core import store
from agents import report_agent as rp

router = APIRouter(tags=["reports"])

_MIME = {"pdf": "application/pdf",
         "excel": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
         "csv": "text/csv"}
_EXT = {"pdf": "pdf", "excel": "xlsx", "csv": "csv"}


@router.get("/reports/{fmt}")
def report(fmt: str, dataset_id: str | None = None):
    if fmt not in _MIME:
        raise HTTPException(400, "Format must be pdf, excel or csv.")
    ds = store.get_dataset(dataset_id) if dataset_id else store.latest_dataset()
    if not ds:
        raise HTTPException(404, "No dataset available.")
    if fmt == "pdf":
        content = rp.build_pdf(ds.df, ds.metadata)
    elif fmt == "excel":
        content = rp.build_excel(ds.df, ds.metadata)
    else:
        content = rp.build_csv(ds.df)
    fname = f"talking-rabbitt-{ds.name.rsplit('.',1)[0]}-{int(time.time())}.{_EXT[fmt]}"
    store.log_report({"name": fname, "format": fmt, "dataset_id": ds.id})
    return Response(content, media_type=_MIME[fmt],
                    headers={"Content-Disposition": f'attachment; filename="{fname}"'})
