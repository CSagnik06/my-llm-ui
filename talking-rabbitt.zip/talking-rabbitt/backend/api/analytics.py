from fastapi import APIRouter, HTTPException
from core import store
from agents import analytics_agent as aa

router = APIRouter(tags=["analytics"])


def _resolve(dataset_id: str | None):
    ds = store.get_dataset(dataset_id) if dataset_id else store.latest_dataset()
    if not ds:
        raise HTTPException(404, "No dataset available. Upload one first.")
    return ds


@router.get("/dashboard")
def dashboard(dataset_id: str | None = None):
    ds = _resolve(dataset_id)
    an = aa.analyze(ds.df, ds.metadata)
    return {"dataset_id": ds.id, "name": ds.name, "kpis": an["kpis"],
            "charts": an["charts"]}


@router.get("/analytics")
def analytics(dataset_id: str | None = None):
    ds = _resolve(dataset_id)
    an = aa.analyze(ds.df, ds.metadata)
    return {"dataset_id": ds.id, **an}
