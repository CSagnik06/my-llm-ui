from fastapi import APIRouter, HTTPException
from core import store
from agents import forecast_agent as fa

router = APIRouter(tags=["forecast"])


@router.get("/forecast")
def forecast(dataset_id: str | None = None, periods: int = 6):
    ds = store.get_dataset(dataset_id) if dataset_id else store.latest_dataset()
    if not ds:
        raise HTTPException(404, "No dataset available.")
    res = fa.forecast(ds.df, ds.metadata, periods=periods)
    store.log_history("forecast", f"Forecast generated for {ds.name}", {"dataset_id": ds.id})
    return {"dataset_id": ds.id, **res}
