from fastapi import APIRouter, HTTPException
from core import store
from agents import recommendation_agent as ra

router = APIRouter(tags=["recommendations"])


@router.get("/recommendations")
def recommendations(dataset_id: str | None = None):
    ds = store.get_dataset(dataset_id) if dataset_id else store.latest_dataset()
    if not ds:
        raise HTTPException(404, "No dataset available.")
    recs = ra.recommend(ds.df, ds.metadata)
    store.log_history("recommendation", f"{len(recs)} recommendations for {ds.name}",
                      {"dataset_id": ds.id})
    return {"dataset_id": ds.id, "recommendations": recs}
