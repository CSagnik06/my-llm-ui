from fastapi import APIRouter
from core import store

router = APIRouter(tags=["history"])


@router.get("/history")
def history():
    return {"history": store.list_history(), "reports": store.list_reports()}
