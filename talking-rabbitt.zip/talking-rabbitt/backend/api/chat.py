import time
from fastapi import APIRouter, HTTPException
from core import store
from core.serialize import to_native
from agents import chat_agent as ca
from .schemas import ChatRequest

router = APIRouter(tags=["chat"])


@router.post("/chat")
def chat(req: ChatRequest):
    ds = store.get_dataset(req.dataset_id) if req.dataset_id else store.latest_dataset()
    if not ds:
        raise HTTPException(404, "No dataset available. Upload one first.")
    hist = store.get_chat(ds.id)
    t = time.strftime("%I:%M %p")
    store.append_chat(ds.id, {"role": "user", "text": req.message, "time": t})
    result = ca.answer(req.message, ds.df, ds.metadata, hist)
    msg = {"role": "ai", "text": result.get("text", ""), "time": time.strftime("%I:%M %p"),
           "table": result.get("table"), "chart": result.get("chart"),
           "note": result.get("note"), "provider": result.get("provider", "builtin")}
    store.append_chat(ds.id, msg)
    return to_native(msg)


@router.get("/chat/history")
def chat_history(dataset_id: str | None = None):
    ds = store.get_dataset(dataset_id) if dataset_id else store.latest_dataset()
    return {"messages": store.get_chat(ds.id) if ds else []}
