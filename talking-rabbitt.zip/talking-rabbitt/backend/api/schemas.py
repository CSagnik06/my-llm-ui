from pydantic import BaseModel

class ChatRequest(BaseModel):
    dataset_id: str | None = None
    message: str

class DBConnectRequest(BaseModel):
    kind: str                 # sqlite | postgresql | mysql
    dsn: str | None = None    # SQLAlchemy URL
    query: str = "SELECT 1"
    name: str | None = None
