from fastapi import APIRouter, UploadFile, File, HTTPException
from core import store, config
from core.serialize import to_native
from agents import ingestion_agent as ia

router = APIRouter(tags=["data"])


@router.post("/upload")
async def upload(file: UploadFile = File(...)):
    raw = await file.read()
    if len(raw) > config.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"File exceeds {config.MAX_UPLOAD_MB} MB limit.")
    if not file.filename.lower().endswith((".csv", ".tsv", ".xlsx", ".xls")):
        raise HTTPException(400, "Only CSV/TSV/Excel files are supported.")
    try:
        df, meta = ia.ingest(raw, file.filename)
    except Exception as e:
        raise HTTPException(422, f"Could not parse file: {e}")
    ds = store.add_dataset(file.filename, df, meta)
    return to_native({"dataset_id": ds.id, "name": ds.name, "metadata": meta})


@router.get("/datasets")
def datasets():
    return {"datasets": store.list_datasets(),
            "active": (store.latest_dataset().id if store.latest_dataset() else None)}


@router.get("/dataset/{dataset_id}")
def dataset(dataset_id: str, limit: int = 50, offset: int = 0):
    ds = store.get_dataset(dataset_id)
    if not ds:
        raise HTTPException(404, "Dataset not found.")
    page = ds.df.iloc[offset:offset + limit]
    rows = page.astype(object).where(page.notna(), None).values.tolist()
    return to_native({"id": ds.id, "name": ds.name, "columns": ds.columns,
            "total": ds.rows, "offset": offset, "limit": limit,
            "rows": rows, "metadata": ds.metadata})
