from fastapi import APIRouter, HTTPException
from core import store
from core.serialize import to_native
from agents import ingestion_agent as ia
from .schemas import DBConnectRequest

router = APIRouter(tags=["database"])


@router.post("/database/connect")
def connect(req: DBConnectRequest):
    """Run a query against a SQL source and register the result as a dataset.

    Requires SQLAlchemy + the relevant driver (psycopg2 / pymysql) to be
    installed. SQLite works out of the box.
    """
    try:
        import sqlalchemy as sa
        import pandas as pd
    except Exception:
        raise HTTPException(500, "Install sqlalchemy to use database connectors.")
    if not req.dsn:
        raise HTTPException(400, "Provide a SQLAlchemy DSN, e.g. sqlite:///data.db")
    try:
        engine = sa.create_engine(req.dsn)
        with engine.connect() as conn:
            df = pd.read_sql(sa.text(req.query), conn)
    except Exception as e:
        raise HTTPException(422, f"Connection/query failed: {e}")
    name = req.name or f"{req.kind}_query"
    _, meta = ia.ingest(df.to_csv(index=False).encode(), f"{name}.csv")
    ds = store.add_dataset(name, df, meta)
    return to_native({"dataset_id": ds.id, "name": ds.name, "metadata": meta})
