// Shared formatting helpers.
export const money = (v) => {
  if (v == null) return '—';
  const a = Math.abs(v);
  if (a >= 1e9) return `$${(v / 1e9).toFixed(1)}B`;
  if (a >= 1e6) return `$${(v / 1e6).toFixed(1)}M`;
  if (a >= 1e3) return `$${(v / 1e3).toFixed(0)}K`;
  return `$${Math.round(v).toLocaleString()}`;
};
export const pct = (cur, prev) => (!prev ? 0 : Math.round(((cur - prev) / Math.abs(prev)) * 1000) / 10);
