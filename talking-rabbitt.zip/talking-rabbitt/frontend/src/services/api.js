// Axios-based API client — the modular reference implementation of the data
// layer that index.html wires inline. Import this from React components built
// with a JSX toolchain, or use it as documentation of the REST contract.
import axios from 'axios';

const http = axios.create({
  baseURL: (import.meta.env?.VITE_API_BASE || '') + '/api',
  timeout: 60000,
});

export const health = () => http.get('/health').then(r => r.data);

export const uploadDataset = (file, onProgress) => {
  const form = new FormData();
  form.append('file', file);
  return http.post('/upload', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: (e) => onProgress && e.total && onProgress(Math.round(e.loaded / e.total * 100)),
  }).then(r => r.data);
};

export const listDatasets = () => http.get('/datasets').then(r => r.data);
export const getDataset = (id, limit = 50, offset = 0) =>
  http.get(`/dataset/${id}`, { params: { limit, offset } }).then(r => r.data);

const q = (id) => (id ? { params: { dataset_id: id } } : {});
export const getDashboard = (id) => http.get('/dashboard', q(id)).then(r => r.data);
export const getAnalytics = (id) => http.get('/analytics', q(id)).then(r => r.data);
export const getRecommendations = (id) => http.get('/recommendations', q(id)).then(r => r.data);
export const getForecast = (id, periods = 6) =>
  http.get('/forecast', { params: { dataset_id: id, periods } }).then(r => r.data);
export const getHistory = () => http.get('/history').then(r => r.data);

export const sendChat = (datasetId, message) =>
  http.post('/chat', { dataset_id: datasetId, message }).then(r => r.data);

export const reportUrl = (fmt, id) =>
  `${http.defaults.baseURL}/reports/${fmt}` + (id ? `?dataset_id=${id}` : '');

export const connectDatabase = (payload) =>
  http.post('/database/connect', payload).then(r => r.data);

export default http;
