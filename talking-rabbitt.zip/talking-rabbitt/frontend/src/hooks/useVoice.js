// Voice Agent hook — Web Speech API (recognition + synthesis).
import { useCallback, useRef, useState } from 'react';

const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;

export function useVoice() {
  const [listening, setListening] = useState(false);
  const recRef = useRef(null);

  const speak = useCallback((text) => {
    try {
      const u = new SpeechSynthesisUtterance(String(text).replace(/[*#•]/g, ''));
      window.speechSynthesis.speak(u);
    } catch (e) { /* unsupported */ }
  }, []);

  const listen = useCallback((onText) => {
    if (!SpeechRec) { alert('Voice recognition not supported in this browser.'); return; }
    const rec = new SpeechRec();
    rec.lang = 'en-US';
    rec.interimResults = false;
    rec.onresult = (e) => onText(e.results[0][0].transcript);
    rec.onend = () => setListening(false);
    rec.start();
    recRef.current = rec;
    setListening(true);
  }, []);

  const stop = useCallback(() => recRef.current && recRef.current.stop(), []);
  return { listening, listen, stop, speak, supported: !!SpeechRec };
}
