// Global BI state — modular React Context reference. The runnable app embeds an
// equivalent BIProvider inline in index.html; this file documents that contract
// for a JSX/TSX build. Import { BIProvider, useBI } and wrap your <App/>.
import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import * as api from '../services/api.js';

const BIContext = createContext(null);
export const useBI = () => useContext(BIContext) || {};

export function BIProvider({ children }) {
  const [state, setState] = useState({
    datasetId: null, meta: null, kpis: null, charts: null, findings: null,
    forecast: null, recommendations: null, history: [], llm: 'none', error: null,
  });
  const merge = (patch) => setState((s) => ({ ...s, ...patch }));

  const refreshAll = useCallback(async (id) => {
    try {
      const dash = await api.getDashboard(id);
      merge({ kpis: dash.kpis, charts: dash.charts });
      const an = await api.getAnalytics(id);
      merge({ findings: an.findings });
      api.getForecast(id).then((f) => merge({ forecast: f })).catch(() => {});
      api.getRecommendations(id).then((r) => merge({ recommendations: r.recommendations })).catch(() => {});
      api.getHistory().then((h) => merge({ history: h.history })).catch(() => {});
    } catch (e) { merge({ error: e.message }); }
  }, []);

  const uploadFile = useCallback(async (file, onProgress) => {
    const res = await api.uploadDataset(file, onProgress);
    merge({ datasetId: res.dataset_id, meta: res.metadata });
    refreshAll(res.dataset_id);
    return res;
  }, [refreshAll]);

  useEffect(() => {
    api.health().then((h) => {
      merge({ llm: h.llm });
      if (h.active_dataset) { merge({ datasetId: h.active_dataset }); refreshAll(h.active_dataset); }
    }).catch(() => {});
  }, [refreshAll]);

  return <BIContext.Provider value={{ ...state, uploadFile, refreshAll }}>{children}</BIContext.Provider>;
}
