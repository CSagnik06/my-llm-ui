import { defineConfig } from 'vite';

// The runnable app is index.html (React via ESM + htm — no JSX build step, so the
// original UI renders byte-for-byte). Vite serves it and proxies /api to FastAPI.
export default defineConfig({
  root: '.',
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: process.env.VITE_API_TARGET || 'http://localhost:8000',
        changeOrigin: true,
      },
    },
  },
  build: { outDir: 'dist' },
});
